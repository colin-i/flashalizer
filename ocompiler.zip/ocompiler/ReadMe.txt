

O Compiler 1.3.16, December 07, 2015


Files and Folders:

src\
- has the source code

changelog.html
- has the history of the program

compiler.html
- explains how to use o.exe

o.html
- O Langauage Documentation file

preferences.txt
- the program parse this file to set the preferences

ReadMe.txt
- this file

make.bat
- Windows bat file to compile the source for executable; the output file will be in the './build/' folder

make_win_gnu
- shell file (msys) to compile the source and to link it with ld (mingw binutils tools); the output file will be in the './buildg/' folder

o.exe
- the program file



Contact:
Write anything about the program at:
oa.netau.net
costin.botescu@gmail.com