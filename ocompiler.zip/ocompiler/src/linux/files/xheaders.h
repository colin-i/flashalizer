


Const PATH_MAX=4096

Const flag_O_BINARY=0
Const flag_MAX_PATH=PATH_MAX

Const flag_O_CREAT=0x0040
const S_IRWXU=0x700;const S_IRGRP=0x40;const S_IROTH=0x4
Const pmode_mode=S_IRWXU|S_IRGRP|S_IROTH

Const X_OK=1
