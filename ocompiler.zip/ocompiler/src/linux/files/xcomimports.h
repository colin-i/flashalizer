

Include "../../files/_/cimports.h"

Import "open" open
Import "close" close
Import "lseek" lseek
Import "read" read
Import "write" write
Import "chdir" chdir
Import "getcwd" getcwd

Import "fprintf" fprintf
Import "stderr" stderr

Import "getpid" getpid
Import "fopen" fopen
Import "fclose" fclose
Import "getdelim" getdelim

import "getenv" getenv
import "access" access