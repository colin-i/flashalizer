

#some ascii Constants commonly used
Const asciiExclamationmark=0x21
Const asciiNumber=0x23
Const asciiand=0x26
Const asciiparenthesisstart=0x28
Const asciiast=0x2A
Const asciiplus=0x2B
Const asciiminus=0x2D
Const asciislash=0x2F
Const asciizero=0x30
Const asciinine=0x39
Const asciiColon=0x3A
Const asciiSemicolon=0x3B
Const asciiaround=0x40
Const asciiA=0x41
Const asciiE=0x45
Const asciiF=0x46
Const asciiL=0x4c
Const asciiZ=0x5A
Const asciibs=0x5C
Const asciiunderscore=0x5F
Const asciia=0x61
Const asciif=0x66
Const asciiz=0x7A
Const asciicirc=0x5E
Const asciivbar=0x7C
Const asciiequiv=0x7E