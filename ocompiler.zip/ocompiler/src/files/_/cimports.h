


Import "realloc" realloc
Import "free" free
Import "sprintf" sprintf
Import "memcpy" memtomem
Import "memset" memset
Import "exit" exit