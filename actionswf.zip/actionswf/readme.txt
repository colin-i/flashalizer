
Action Swf v1.1.31
for Windows 32-bit and 64-bit

Action Swf can create swf files.
The program is a set of objects made with O Language.
A swf with actionscript example is in the example folder for static o language 32-bit and 64-bit, for shared c and c++.
The dev folder has the imports and the links. The include/actionswf.h is for c/c++ language.
The files swf.s and action.s has the main functions that can be used.

The ocompiler.zip is in the same folder with this program
The linux ocompiler.tar.gz is in the same folder with this program