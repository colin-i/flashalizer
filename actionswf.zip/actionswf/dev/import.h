

#swf

#id
importX "swf_button" swf_button
#id
importX "swf_button_last" swf_button_last
#id
importX "swf_font" swf_font
#id
importX "swf_font_basic" swf_font_basic
#id
importX "swf_text" swf_text
#id
importX "swf_shape" swf_shape
#id
importX "swf_shape_basic" swf_shape_basic
#id
importX "swf_shape_bitmap" swf_shape_bitmap
#id
importX "swf_shape_border" swf_shape_border
#id
importX "swf_image" swf_image
#id
importX "swf_image_ex" swf_image_ex
#dbl
#id
importX "swf_dbl" swf_dbl
#id
importX "swf_dbl_ex" swf_dbl_ex
#width
importX "swf_dbl_width" swf_dbl_width
#height
importX "swf_dbl_height" swf_dbl_height
#utils
importX "swf_done" swf_done
importX "swf_new" swf_new
importX "swf_placeobject" swf_placeobject
importX "swf_placeobject_coords" swf_placeobject_coords
importX "swf_removeobject" swf_removeobject
importX "swf_showframe" swf_showframe

#sprite

#id
importX "swf_sprite_done" swf_sprite_done
#preid
importX "swf_sprite_new" swf_sprite_new
importX "swf_sprite_placeobject" swf_sprite_placeobject
importX "swf_sprite_placeobject_coords" swf_sprite_placeobject_coords
importX "swf_sprite_removeobject" swf_sprite_removeobject
importX "swf_sprite_showframe" swf_sprite_showframe

#swf exports

importX "swf_exports_add" swf_exports_add
importX "swf_exports_done" swf_exports_done

#actionscript

importX "action" action
importX "actionf" actionf
importX "action_sprite" action_sprite
importX "actionf_sprite" actionf_sprite

#tool

import "erbool_get" erbool_get
import "erbool_reset" erbool_reset
import "abort" abort