

O Compiler 1.3.16, December 07, 2015


Files and Folders:

src\
- has the source code

changelog.html
- has the history of the program

compiler.html
- explains how to use o.exe

o.html
- O Langauage Documentation file

preferences.txt
- the program parse this file to set the preferences

ReadMe.txt
- this file

make
- Linux shell file to compile the source for executable; the output file will be in the './build/' folder

make_lin_gnu
- Linux shell file to compile the source and to link it with gcc (mingw binutils tools); the output file will be in the './buildg/' folder

make_win64_fromLin_gnu
- Linux shell file to compile the source and to link it with mingw-w64 for linux; the output file will be in the './buildg/' folder
fix64
- fix for symbols folder

o
- the program file



Contact:
Write anything about the program at:
costin.botescu@gmail.com