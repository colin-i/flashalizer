

Const ifinscribe=-1
Const ifnumber=0
Const elsenumber=1
Const whilenumber=2

Const condmiscs=whilenumber+1

Const elseifnumber=condmiscs+0

Const condends=elseifnumber+1

Const endifnumber=condends+ifnumber
Const endelsenumber=condends+elsenumber
Const endwhilenumber=condends+whilenumber

Const endelseifnumber=condends+elseifnumber

Const nocondnumber=-1